import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import {GlobalVariable} from '../../Config/app.confic';

@Injectable()
export class GoalslistService {

  constructor(private http: HttpClient) {
  }
  
  getGoals(id:any): Observable<any>{
      return this.http.get(GlobalVariable.API_URL+'goals/mentee/'+id)
      .map((response: Response)  => response);
  
   }
   viewGoals(id:any): Observable<any>{
    return this.http.get(GlobalVariable.API_URL+'vewgoals/'+id)
    .map((response: Response)  => response);

 } deleteGoals(id:any): Observable<any>{
  return this.http.delete(GlobalVariable.API_URL+'deletegoals/'+id)
  .map((response: Response)  => response);

}
}
