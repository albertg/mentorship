import { TestBed, inject } from '@angular/core/testing';

import { GoalslistService } from './goalslist.service';

describe('GoalslistService', () => {
  /*beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GoalslistService]
    });
  });

  it('should be created', inject([GoalslistService], (service: GoalslistService) => {
    expect(service).toBeTruthy();
  }));*/
});
