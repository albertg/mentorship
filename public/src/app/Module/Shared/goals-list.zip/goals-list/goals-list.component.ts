import { Component, OnInit, Input } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import {GoalslistService} from './goalslist.service';
import { UserserviceService } from '../../_service/userservice.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-goals-list',
  templateUrl: './goals-list.component.html',
  styleUrls: ['./goals-list.component.css']
})
export class GoalsListComponent implements OnInit {

  modeldata;
  shorttermgoals=[];
  mediumtermgoals=[];
  longtermgoals=[];
  button=false;
  goalid;
  @Input() menteeid: string;
  @Input() menu: string;
  constructor(private api:GoalslistService,
    private Userservice:UserserviceService,
    private router: Router) { }
  ngOnInit() {
    if(this.menu==='true'){
      this.button=true;
  }
    this.api.getGoals(parseInt(this.menteeid)).subscribe(data => {
      
      data.forEach(element => {

        if(element.goalType.id==3){
          this.longtermgoals.push(element);
        }
        else if(element.goalType.id==2){
          this.mediumtermgoals.push(element);
        }
        else if(element.goalType.id==1){
          this.shorttermgoals.push(element);
        };
        
      });
     // console.log(data[0]);
  });
  }

  viewgoal(id){
    this.api.viewGoals(id).subscribe(data => {

      this.modeldata=data.Body;
      this.goalid=data.id;
    });
    
  }
  delete(id){
    this.api.deleteGoals(id).subscribe(data => {
      $('.goals-'+id).closest( "li" ).hide();
     // $('#viewgoals').hide();
     $("[data-dismiss=modal]").trigger('click');
    });
    
  }
  edit(){

  }

}
